import os

os.environ["USE_MOCK_LLM"] = "true"

from app.TradingResearchAgent.graph import build_trading_graph


def test_graph_returns_decision():
    graph = build_trading_graph()
    result = graph.invoke({
        "symbol": "AAPL",
        "query": "Test research analysis"
    })

    assert result["decision"]["symbol"] == "AAPL"
    assert result["decision"]["stance"] in {"BULLISH", "NEUTRAL", "BEARISH"}
    assert 0 <= result["decision"]["confidence"] <= 1
