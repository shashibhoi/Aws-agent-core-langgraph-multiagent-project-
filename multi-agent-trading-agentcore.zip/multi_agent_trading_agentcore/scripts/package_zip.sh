#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/deployment_package"

rm -rf "$OUT" "$ROOT/deployment_package.zip"
mkdir -p "$OUT"

echo "For production, prefer: agentcore deploy"
echo "This helper packages application source only; native dependencies should be built for AgentCore's Linux/arm64 environment."

cp -R "$ROOT/app/TradingResearchAgent" "$OUT/TradingResearchAgent"

cd "$OUT"
zip -r "$ROOT/deployment_package.zip" .
echo "Created $ROOT/deployment_package.zip"
