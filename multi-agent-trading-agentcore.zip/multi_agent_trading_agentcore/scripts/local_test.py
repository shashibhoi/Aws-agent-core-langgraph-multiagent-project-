import os
os.environ.setdefault("USE_MOCK_LLM", "true")

from app.TradingResearchAgent.graph import build_trading_graph

graph = build_trading_graph()

result = graph.invoke({
    "symbol": "AAPL",
    "query": "Run a research-only multi-agent analysis."
})

print(result["decision"])
