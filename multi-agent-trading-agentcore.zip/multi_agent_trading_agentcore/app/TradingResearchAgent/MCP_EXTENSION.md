# MCP extension point

The current application keeps external operations behind `tools/`.

For a production MCP version, expose deterministic operations such as:

- `get_market_data(symbol, period)`
- `get_company_fundamentals(symbol)`
- `get_news(symbol)`
- `calculate_indicators(symbol, period)`
- `get_portfolio_exposure()`

The agent should discover/call these tools rather than embedding external API logic into prompts.

When deploying an MCP server directly to AgentCore Runtime, follow the current AgentCore MCP contract: Streamable HTTP, with the server listening on `0.0.0.0:8000` and exposing `/mcp`. AgentCore documents both stateless and stateful MCP modes; stateless is the default recommended mode for compatibility with runtime session handling.

Do not add order-placement tools until authentication, authorization, audit logging, risk controls and human approval are designed.
