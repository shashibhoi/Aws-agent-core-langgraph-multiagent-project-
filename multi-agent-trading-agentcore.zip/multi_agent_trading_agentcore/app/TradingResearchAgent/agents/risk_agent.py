from ..config import settings
from ..prompts import RISK_SYSTEM
from ..tools.risk import calculate_risk_metrics


def run_risk_agent(symbol: str, market_data: dict, llm=None):
    metrics = calculate_risk_metrics(market_data)

    if settings.use_mock_llm or llm is None:
        analysis = (
            f"Risk snapshot for {symbol}: annualized volatility="
            f"{metrics['annualized_volatility']}, max drawdown={metrics['max_drawdown']}."
        )
    else:
        response = llm.invoke([
            ("system", RISK_SYSTEM),
            ("human", f"Symbol: {symbol}\nRisk metrics: {metrics}")
        ])
        analysis = response.content

    return {"metrics": metrics, "analysis": analysis}
