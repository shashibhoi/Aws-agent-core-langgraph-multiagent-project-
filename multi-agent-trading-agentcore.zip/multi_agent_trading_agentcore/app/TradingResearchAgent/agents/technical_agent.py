from ..config import settings
from ..prompts import TECHNICAL_SYSTEM
from ..tools.technical import calculate_indicators


def run_technical_agent(symbol: str, market_data: dict, llm=None):
    indicators = calculate_indicators(market_data)

    if settings.use_mock_llm or llm is None:
        analysis = (
            f"Technical snapshot for {symbol}: "
            f"SMA20={indicators['sma20']}, SMA50={indicators['sma50']}, "
            f"RSI14={indicators['rsi14']}, MACD={indicators['macd']}. "
            "Use the values as research signals, not trade instructions."
        )
    else:
        response = llm.invoke([
            ("system", TECHNICAL_SYSTEM),
            ("human", f"Symbol: {symbol}\nIndicators: {indicators}")
        ])
        analysis = response.content

    return {"indicators": indicators, "analysis": analysis}
