import json

from ..config import settings
from ..models import Decision
from ..prompts import DECISION_SYSTEM


def run_decision_agent(symbol: str, market_analysis: str, technical_analysis: str,
                       risk_analysis: str, llm=None) -> Decision:
    if settings.use_mock_llm or llm is None:
        return Decision(
            symbol=symbol,
            stance="NEUTRAL",
            confidence=0.50,
            rationale="Mock mode: deterministic neutral result for local testing.",
            scenario="Validate the signals with current, authoritative market data before making any decision.",
            risk_flags=["MOCK_MODE", "NOT_FOR_LIVE_TRADING"],
        )

    response = llm.invoke([
        ("system", DECISION_SYSTEM),
        ("human", f"""
Symbol: {symbol}

Market analysis:
{market_analysis}

Technical analysis:
{technical_analysis}

Risk analysis:
{risk_analysis}

Return JSON with:
symbol, stance, confidence, rationale, scenario, risk_flags
""")
    content = response.content

    # Bedrock/LangChain responses can contain fenced JSON.
    cleaned = content.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.replace("```json", "").replace("```", "").strip()

    try:
        return Decision.model_validate(json.loads(cleaned))
    except Exception:
        # Keep the system useful even if the LLM returns non-JSON.
        return Decision(
            symbol=symbol,
            stance="NEUTRAL",
            confidence=0.20,
            rationale=content[:3000],
            scenario="LLM output was not valid structured JSON; manual review required.",
            risk_flags=["UNSTRUCTURED_LLM_OUTPUT"],
        )
