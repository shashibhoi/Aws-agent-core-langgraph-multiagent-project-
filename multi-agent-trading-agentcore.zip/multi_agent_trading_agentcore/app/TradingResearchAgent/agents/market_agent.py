from ..config import settings
from ..prompts import MARKET_SYSTEM
from ..tools.market_data import get_market_data


def run_market_agent(symbol: str, query: str, llm=None):
    data = get_market_data(symbol)

    if settings.use_mock_llm or llm is None:
        latest = data["latest"]
        analysis = (
            f"{symbol} latest close is {latest['close']}. "
            f"The dataset contains {data['row_count']} observations. "
            "This is a local deterministic smoke-test summary."
        )
    else:
        response = llm.invoke([
            ("system", MARKET_SYSTEM),
            ("human", f"Research request: {query}\n\nMarket data:\n{data}")
        ])
        analysis = response.content

    return data, analysis
