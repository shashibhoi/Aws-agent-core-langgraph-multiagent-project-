from __future__ import annotations

import logging

from bedrock_agentcore.runtime import BedrockAgentCoreApp

from .graph import build_trading_graph
from .models import TradingResearchReport

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = BedrockAgentCoreApp()
graph = build_trading_graph()


@app.entrypoint
def invoke(payload, context):
    """AgentCore Runtime entry point."""
    if not isinstance(payload, dict):
        return {"error": "Payload must be a JSON object."}

    symbol = str(payload.get("symbol", "")).strip().upper()
    query = str(payload.get("query", "")).strip()

    if not symbol:
        return {"error": "Missing required field: symbol."}

    if not query:
        query = f"Provide a research analysis for {symbol}."

    logger.info("Starting trading research for %s", symbol)

    result = graph.invoke({
        "symbol": symbol,
        "query": query,
    })

    report = TradingResearchReport(
        symbol=symbol,
        query=query,
        market_analysis=result["market_analysis"],
        technical_analysis=result["technical_analysis"],
        risk_analysis=result["risk_analysis"],
        decision=result["decision"],
    )

    return report.model_dump()


if __name__ == "__main__":
    app.run()
