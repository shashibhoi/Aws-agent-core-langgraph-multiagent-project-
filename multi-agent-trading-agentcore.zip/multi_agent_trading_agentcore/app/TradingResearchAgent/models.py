from typing import Literal
from pydantic import BaseModel, Field


class Decision(BaseModel):
    symbol: str
    stance: Literal["BULLISH", "NEUTRAL", "BEARISH"]
    confidence: float = Field(ge=0, le=1)
    rationale: str
    scenario: str
    risk_flags: list[str] = Field(default_factory=list)


class TradingResearchReport(BaseModel):
    symbol: str
    query: str
    market_analysis: str
    technical_analysis: str
    risk_analysis: str
    decision: Decision
