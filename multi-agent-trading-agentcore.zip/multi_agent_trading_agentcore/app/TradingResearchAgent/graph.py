from langchain_aws import ChatBedrockConverse
from langgraph.graph import END, START, StateGraph

from .agents.decision_agent import run_decision_agent
from .agents.market_agent import run_market_agent
from .agents.risk_agent import run_risk_agent
from .agents.technical_agent import run_technical_agent
from .config import settings
from .state import TradingState


def build_llm():
    if settings.use_mock_llm:
        return None

    return ChatBedrockConverse(
        model=settings.bedrock_model_id,
        region_name=settings.aws_region,
        temperature=0,
        max_tokens=2500,
    )


def build_trading_graph():
    llm = build_llm()

    def market_node(state: TradingState):
        data, analysis = run_market_agent(
            state["symbol"], state["query"], llm
        )
        return {"market_data": data, "market_analysis": analysis}

    def technical_node(state: TradingState):
        result = run_technical_agent(
            state["symbol"], state["market_data"], llm
        )
        return {"technical_analysis": result["analysis"]}

    def risk_node(state: TradingState):
        result = run_risk_agent(
            state["symbol"], state["market_data"], llm
        )
        return {"risk_analysis": result["analysis"]}

    def decision_node(state: TradingState):
        decision = run_decision_agent(
            state["symbol"],
            state["market_analysis"],
            state["technical_analysis"],
            state["risk_analysis"],
            llm,
        )
        return {"decision": decision.model_dump()}

    graph = StateGraph(TradingState)
    graph.add_node("market", market_node)
    graph.add_node("technical", technical_node)
    graph.add_node("risk", risk_node)
    graph.add_node("decision", decision_node)

    graph.add_edge(START, "market")
    graph.add_edge("market", "technical")
    graph.add_edge("technical", "risk")
    graph.add_edge("risk", "decision")
    graph.add_edge("decision", END)

    return graph.compile()
