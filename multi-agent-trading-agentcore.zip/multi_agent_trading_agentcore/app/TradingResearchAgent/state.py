from typing import Any, TypedDict


class TradingState(TypedDict, total=False):
    symbol: str
    query: str
    market_data: dict[str, Any]
    market_analysis: str
    technical_analysis: str
    risk_analysis: str
    decision: dict[str, Any]
    errors: list[str]
