from __future__ import annotations

import pandas as pd
from ta.momentum import RSIIndicator
from ta.trend import MACD, SMAIndicator
from ta.volatility import AverageTrueRange


def calculate_indicators(market_data: dict) -> dict:
    rows = market_data["rows"]
    df = pd.DataFrame(rows)

    for col in ["open", "high", "low", "close", "volume"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    close = df["close"]
    high = df["high"]
    low = df["low"]

    sma20 = SMAIndicator(close, window=20).sma_indicator()
    sma50 = SMAIndicator(close, window=50).sma_indicator()
    rsi = RSIIndicator(close, window=14).rsi()
    macd = MACD(close)
    atr = AverageTrueRange(high, low, close, window=14).average_true_range()

    latest_close = float(close.iloc[-1])

    return {
        "latest_close": latest_close,
        "sma20": float(sma20.iloc[-1]) if pd.notna(sma20.iloc[-1]) else None,
        "sma50": float(sma50.iloc[-1]) if pd.notna(sma50.iloc[-1]) else None,
        "rsi14": float(rsi.iloc[-1]) if pd.notna(rsi.iloc[-1]) else None,
        "macd": float(macd.macd().iloc[-1]) if pd.notna(macd.macd().iloc[-1]) else None,
        "macd_signal": float(macd.macd_signal().iloc[-1]) if pd.notna(macd.macd_signal().iloc[-1]) else None,
        "atr14": float(atr.iloc[-1]) if pd.notna(atr.iloc[-1]) else None,
    }
