from __future__ import annotations

import numpy as np
import pandas as pd


def calculate_risk_metrics(market_data: dict) -> dict:
    df = pd.DataFrame(market_data["rows"])
    close = pd.to_numeric(df["close"], errors="coerce").dropna()

    returns = close.pct_change().dropna()

    if returns.empty:
        return {
            "annualized_volatility": None,
            "max_drawdown": None,
            "observations": 0,
        }

    annualized_volatility = float(returns.std() * np.sqrt(252))

    cumulative = (1 + returns).cumprod()
    peak = cumulative.cummax()
    drawdown = cumulative / peak - 1
    max_drawdown = float(drawdown.min())

    return {
        "annualized_volatility": annualized_volatility,
        "max_drawdown": max_drawdown,
        "observations": int(len(returns)),
    }
