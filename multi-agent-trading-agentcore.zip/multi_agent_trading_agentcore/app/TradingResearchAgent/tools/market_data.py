from __future__ import annotations

import math
from typing import Any

import yfinance as yf

from ..config import settings


def _clean(value: Any) -> Any:
    if value is None:
        return None
    try:
        if math.isnan(float(value)):
            return None
    except (TypeError, ValueError):
        pass
    return value


def get_market_data(symbol: str, period: str | None = None) -> dict[str, Any]:
    symbol = symbol.strip().upper()
    period = period or settings.market_data_period

    ticker = yf.Ticker(symbol)
    hist = ticker.history(period=period, auto_adjust=True)

    if hist.empty:
        raise ValueError(f"No market data returned for symbol: {symbol}")

    hist = hist.dropna()
    recent = hist.tail(120).copy()

    rows = []
    for idx, row in recent.iterrows():
        rows.append({
            "date": idx.strftime("%Y-%m-%d"),
            "open": _clean(row.get("Open")),
            "high": _clean(row.get("High")),
            "low": _clean(row.get("Low")),
            "close": _clean(row.get("Close")),
            "volume": _clean(row.get("Volume")),
        })

    last = rows[-1]

    return {
        "symbol": symbol,
        "period": period,
        "latest": last,
        "rows": rows,
        "row_count": len(rows),
    }
