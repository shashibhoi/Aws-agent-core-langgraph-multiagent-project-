from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    aws_region: str = "ap-south-1"
    bedrock_model_id: str = "global.anthropic.claude-sonnet-4-5-20250929-v1:0"
    use_mock_llm: bool = False
    market_data_period: str = "6mo"
    log_level: str = "INFO"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )


settings = Settings()
